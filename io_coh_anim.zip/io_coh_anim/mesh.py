"""
Blender mesh creation and extraction for CoH GEO files.

Converts between GEO binary format data classes and Blender mesh objects.
Handles coordinate conversion, UV mapping, material assignment, and
optional bone skinning.

Similar to armature.py but for geometry instead of animations.
"""

try:
    import bpy
    import bmesh
    _HAS_BPY = True
except ImportError:
    _HAS_BPY = False

from .formats.geo import GeoFile, GeoModel, GeoHeader, TexID
from .core.coords import game_to_blender, blender_to_game
import math


# ─── Import: GEO → Blender ──────────────────────────────────────────────


def mesh_from_geo(context, geo_file, name="GEO_Import"):
    """Create Blender mesh objects from a GEO file.

    Args:
        context: Blender context
        geo_file: GeoFile data
        name: Base name for created objects

    Returns:
        List of created Blender objects
    """
    objects = []

    for model in geo_file.models:
        obj = _create_mesh_object(context, model, geo_file.tex_names)
        objects.append(obj)

    return objects


def _create_mesh_object(context, model, tex_names):
    """Create a single Blender mesh object from a GeoModel."""
    mesh = bpy.data.meshes.new(model.name)
    obj = bpy.data.objects.new(model.name, mesh)

    # Convert vertices from game to Blender coordinates
    verts = [game_to_blender(v) for v in model.vertices]
    faces = list(model.triangles)

    mesh.from_pydata(verts, [], faces)
    mesh.update()

    # UV mapping
    if model.uvs:
        uv_layer = mesh.uv_layers.new(name="UVMap")
        for poly in mesh.polygons:
            for li, vi in zip(poly.loop_indices, poly.vertices):
                if vi < len(model.uvs):
                    u, v = model.uvs[vi]
                    # Blender UVs: flip V axis (game uses top-left origin)
                    uv_layer.data[li].uv = (u, 1.0 - v)

    # Secondary UV set
    if model.uvs2:
        uv_layer2 = mesh.uv_layers.new(name="UVMap2")
        for poly in mesh.polygons:
            for li, vi in zip(poly.loop_indices, poly.vertices):
                if vi < len(model.uvs2):
                    u, v = model.uvs2[vi]
                    uv_layer2.data[li].uv = (u, 1.0 - v)

    # Create materials from texture names
    _assign_materials(mesh, model, tex_names)

    # Custom normals
    if model.normals:
        normals = [game_to_blender(n) for n in model.normals]
        # Set normals per-loop
        loop_normals = []
        for poly in mesh.polygons:
            for vi in poly.vertices:
                if vi < len(normals):
                    loop_normals.append(normals[vi])
                else:
                    loop_normals.append((0.0, 0.0, 1.0))
        mesh.normals_split_custom_set(loop_normals)

    # Link to scene
    context.collection.objects.link(obj)

    # Skinning (vertex groups from BoneInfo)
    if model.bone_info and model.bone_info.weights:
        _apply_skinning(obj, model)

    return obj


def _assign_materials(mesh, model, tex_names):
    """Assign materials based on TexID runs."""
    if not model.tex_ids:
        return

    # Create a material for each referenced texture
    mat_indices = {}
    for tex_id_entry in model.tex_ids:
        tid = tex_id_entry.id
        if tid not in mat_indices:
            tex_name = tex_names[tid] if tid < len(tex_names) else f"material_{tid}"
            mat = bpy.data.materials.get(tex_name) or bpy.data.materials.new(tex_name)
            mat_indices[tid] = len(mesh.materials)
            mesh.materials.append(mat)

    # Assign material index to each triangle based on TexID runs
    tri_idx = 0
    for tex_id_entry in model.tex_ids:
        mat_idx = mat_indices.get(tex_id_entry.id, 0)
        for _ in range(tex_id_entry.count):
            if tri_idx < len(mesh.polygons):
                mesh.polygons[tri_idx].material_index = mat_idx
            tri_idx += 1


def _apply_skinning(obj, model):
    """Apply bone skinning data from GeoModel.bone_info to vertex groups."""
    bi = model.bone_info
    if not bi or not bi.matidxs:
        return

    # Create vertex groups for each bone
    bone_groups = {}
    bone_ids = bi.bone_ids if bi.bone_ids else list(range(bi.numbones))

    for bone_id in bone_ids:
        if bone_id not in bone_groups:
            group_name = f"bone_{bone_id}"
            vg = obj.vertex_groups.new(name=group_name)
            bone_groups[bone_id] = vg

    # Assign weights
    for vi in range(model.vert_count):
        if vi >= len(bi.matidxs) or vi >= len(bi.weights):
            continue

        idx0, idx1 = bi.matidxs[vi]
        weight = bi.weights[vi]

        if idx0 < len(bone_ids):
            bid0 = bone_ids[idx0]
            if bid0 in bone_groups:
                bone_groups[bid0].add([vi], weight, 'REPLACE')

        if idx1 < len(bone_ids) and weight < 1.0:
            bid1 = bone_ids[idx1]
            if bid1 in bone_groups:
                bone_groups[bid1].add([vi], 1.0 - weight, 'REPLACE')


# ─── Export: Blender → GEO ──────────────────────────────────────────────


def geo_from_mesh(context, objects, geo_name="custom"):
    """Create a GeoFile from selected Blender mesh objects.

    Args:
        context: Blender context
        objects: List of Blender mesh objects
        geo_name: Name for the GEO file header

    Returns:
        GeoFile ready for writing
    """
    all_tex_names = []
    tex_name_map = {}
    models = []

    for obj in objects:
        if obj.type != 'MESH':
            continue

        model = _extract_mesh(context, obj, all_tex_names, tex_name_map)
        models.append(model)

    obj_names = [m.name for m in models]

    return GeoFile(
        version=8,
        headers=[GeoHeader(name=f"{geo_name}.wrl", model_count=len(models))],
        models=models,
        tex_names=all_tex_names,
        obj_names=obj_names,
    )


def _extract_mesh(context, obj, all_tex_names, tex_name_map):
    """Extract GeoModel data from a Blender mesh object."""
    # Get evaluated mesh (apply modifiers)
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()

    # Triangulate
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    mesh.calc_loop_triangles()

    # Extract vertices (Blender → game coords)
    vertices = []
    for v in mesh.vertices:
        vertices.append(blender_to_game((v.co.x, v.co.y, v.co.z)))

    # Extract normals
    normals = []
    for v in mesh.vertices:
        normals.append(blender_to_game((v.normal.x, v.normal.y, v.normal.z)))

    # Extract UVs (per-vertex from first UV layer)
    uvs = []
    uv_layer = mesh.uv_layers.active
    if uv_layer:
        # Build per-vertex UVs (use first loop's UV for each vertex)
        vertex_uvs = [None] * len(mesh.vertices)
        for poly in mesh.polygons:
            for li, vi in zip(poly.loop_indices, poly.vertices):
                if vertex_uvs[vi] is None:
                    u, v = uv_layer.data[li].uv
                    vertex_uvs[vi] = (u, 1.0 - v)  # Flip V back
        for uv in vertex_uvs:
            uvs.append(uv if uv else (0.0, 0.0))

    # Extract triangles sorted by material for TexID runs
    triangles = []
    tex_ids = []

    # Group triangles by material index
    mat_groups = {}
    for poly in mesh.polygons:
        mi = poly.material_index
        if mi not in mat_groups:
            mat_groups[mi] = []
        mat_groups[mi].append(tuple(poly.vertices))

    # Build sorted triangle list and TexID runs
    for mi in sorted(mat_groups.keys()):
        tris = mat_groups[mi]

        # Get texture name from material
        if mi < len(mesh.materials) and mesh.materials[mi]:
            tex_name = mesh.materials[mi].name
        else:
            tex_name = "white"

        # Register texture name
        if tex_name not in tex_name_map:
            tex_name_map[tex_name] = len(all_tex_names)
            all_tex_names.append(tex_name)

        tid = tex_name_map[tex_name]
        tex_ids.append(TexID(id=tid, count=len(tris)))
        triangles.extend(tris)

    # Calculate bounding box
    if vertices:
        xs = [v[0] for v in vertices]
        ys = [v[1] for v in vertices]
        zs = [v[2] for v in vertices]
        min_bound = (min(xs), min(ys), min(zs))
        max_bound = (max(xs), max(ys), max(zs))
        # Radius = distance from origin to farthest vertex
        radius = max(math.sqrt(x*x + y*y + z*z) for x, y, z in vertices)
    else:
        min_bound = (0.0, 0.0, 0.0)
        max_bound = (0.0, 0.0, 0.0)
        radius = 0.0

    model = GeoModel(
        name=f"GEO_{obj.name}",
        radius=radius,
        min=min_bound,
        max=max_bound,
        vert_count=len(vertices),
        tri_count=len(triangles),
        vertices=vertices,
        normals=normals,
        uvs=uvs,
        triangles=triangles,
        tex_ids=tex_ids,
    )

    eval_obj.to_mesh_clear()
    return model
